﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruPOC
{
    public static class ExtensionMethods
    {
        public static DateTime ToEST(this DateTime dateTime)
        {
            return dateTime.Subtract(new TimeSpan(0, 4, 0, 0));
        }
    }
}
