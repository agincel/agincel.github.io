using System;
using System.Collections.Generic;
using System.Linq;
using Alexa.NET;
using Amazon.Lambda.Core;

using Alexa.NET.Request;
using Alexa.NET.Request.Type;
using Alexa.NET.Response;
using Alexa.NET.Response.Directive;
using Newtonsoft.Json;
using PruPOC.Salesforce;
using PruPOC.Salesforce.Objects;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.Json.JsonSerializer))]
namespace PruPOC
{
    public class Function
    {
        private static readonly string SalesforceUserId = "0051a000002zf6aAAA"; // The Salesforce User ID who the service is running as. (Matt Beutel)

        /// <summary>
        /// A simple function that takes a string and does a ToUpper
        /// </summary>
        /// <param name="input"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public SkillResponse FunctionHandler(SkillRequest input, ILambdaContext context)
        {
            var log = context.Logger;

            SkillResponse response = null;
            bool endSession = false;

            try
            {
                log.LogLine("Skill Request: ");
                log.LogLine(JsonConvert.SerializeObject(input));

                if (input.GetRequestType() == typeof(LaunchRequest))
                {
                    response =  ResponseBuilder.Ask(AlexaResponses.StartMessage, new Reprompt { OutputSpeech = new PlainTextOutputSpeech { Text = AlexaResponses.HelpPrompt } }, input.Session);
                }
                else if (input.GetRequestType() == typeof(SessionEndedRequest))
                {
                    response = ResponseBuilder.Tell(AlexaResponses.EndSession);

                    endSession = true;
                }
                else if (input.GetRequestType() == typeof(IntentRequest))
                {
                    var intentRequest = (IntentRequest)input.Request;
                    log.LogLine(intentRequest.Intent.Name);

                    switch (intentRequest.Intent.Name)
                    {
                        case "AMAZON.CancelIntent":
                            response = ResponseBuilder.Tell(AlexaResponses.StopMessage);

                            break;
                        case "AMAZON.StopIntent":
                            response = ResponseBuilder.Tell(AlexaResponses.EndSession);
                            endSession = true;

                            break;
                        case "AMAZON.HelpIntent":
                            response = ResponseBuilder.Tell(AlexaResponses.HelpMessage);

                            break;
                        case "AMAZON.FallbackIntent":
                            response = ResponseBuilder.Tell(AlexaResponses.HelpMessage);

                            break;
                        case "NextMeetingIntent":
                            response = Handler_NextMeetingIntent(input);

                            break;
                        case "NextMeetingLocationIntent":
                            response = Handler_NextMeetingLocationIntent(input);

                            break;
                        case "NextMeetingDirectionsIntent":
                            response = Handler_NextMeetingDirectionsIntent(input);

                            break;
                        case "ContactInfoIntent":
                            response = Handler_ContactInfoIntent(input);

                            break;
                        case "ContactPersonalInfoIntent":
                            response = Handler_ContactPersonalInfoIntent(input);

                            break;
                        case "GetOpportunityIntent":
                            response = Handler_GetOpportunityIntent(input);

                            break;
                        case "UpdateOpportunityIntent":
                            response = Handler_UpdateOpportunityIntent(input);

                            break;
                        case "ThankYouNoteIntent":
                            response = Handler_ThankYouNoteIntent(input);

                            break;
                        case "WorkWithFPIntent":
                            response = Handler_WorkWithFPIntent(input);

                            break;
                        case "MusicIntent":
                            response = Handler_MusicIntent(input);

                            break;
                        case "GeeThanksIntent":
                            response = Handler_GeeThanksIntent(input);
                            endSession = true;

                            break;
                        default:
                            response = ResponseBuilder.Tell(AlexaResponses.HelpMessage);

                            break;
                    }
                }
                
                log.LogLine($"Skill Response Object: ");
                log.LogLine(JsonConvert.SerializeObject(response));
            }
            catch (Exception ex)
            {
                log.Log(ex.ToString());
            }


            response.SessionAttributes = input.Session.Attributes; // Ensure session is always retained.
            response.Response.ShouldEndSession = endSession;

            return response;
        }

        #region Intent Handlers

        private static SkillResponse Handler_NextMeetingIntent(SkillRequest input)
        {
            #if !DEBUG
            var progressiveResponse = new ProgressiveResponse(input);

            progressiveResponse.SendSpeech("Please wait while I search for your meetings.");
            #endif

            var resultEvent = SalesforceClient.Query<SF_Event_Result>(SF_Event.Query_NextEvent(SalesforceUserId));
            var nextEvent = resultEvent.records.FirstOrDefault();

            if (nextEvent == null)
            {
                return ResponseBuilder.Tell("You do not have any more meetings for today.");
            }

            var contactResult = SalesforceClient.Query<SF_Contact_Result>(SF_Contact.Query_GetContactById(nextEvent.WhoId));
            var contact = contactResult.records.FirstOrDefault();

            SetSessionVar(input, "FP", contact.Id);
            SetSessionVar(input, "Event", nextEvent.Id);
            SetSessionVar(input, "FP_Name", contact.Full_Name__c);

            // Construct the meeting date/time string
            var dateTimeMessage = "";
            var activityDateTime = nextEvent.ActivityDateTime;

            if (activityDateTime.Date.Equals(DateTime.Now.Date))
            {
                dateTimeMessage = $"today at {activityDateTime.ToEST().ToShortTimeString()}";
            }
            else if ((activityDateTime.Date - DateTime.Now.Date).TotalDays == 1)
            {
                dateTimeMessage = $"tomorrow at {activityDateTime.ToEST().ToShortTimeString()}";
            }
            else
            {
                dateTimeMessage = $"on {activityDateTime.ToEST().ToShortDateString()} at {activityDateTime.ToEST().ToShortTimeString()}";
            }

            return ResponseBuilder.Tell($"Your next meeting is {dateTimeMessage} with {contact.Full_Name__c} in {nextEvent.City_ma__c} {States[nextEvent.State_ma__c]}");
        }

        /**
         * Complete
         */
        private static SkillResponse Handler_NextMeetingLocationIntent(SkillRequest input)
        {
            var resultEvent = SalesforceClient.Query<SF_Event_Result>(SF_Event.Query_NextEvent(SalesforceUserId));
            var nextEvent = resultEvent.records.FirstOrDefault();

            if (nextEvent == null)
            {
                return ResponseBuilder.Tell("You do not have anymore meetings for today.");
            }

            var contactResult = SalesforceClient.Query<SF_Contact_Result>(SF_Contact.Query_GetContactById(nextEvent.WhoId));
            var contact = contactResult.records.FirstOrDefault();

            SetSessionVar(input, "FP", contact.Id);
            SetSessionVar(input, "Event", nextEvent.Id);
            SetSessionVar(input, "FP_Name", contact.Full_Name__c);

            return ResponseBuilder.Tell($"Your meeting with {contact.Full_Name__c} is at {nextEvent.Street_ma__c} {nextEvent.City_ma__c} {States[nextEvent.State_ma__c]}");
        }

        private static SkillResponse Handler_NextMeetingDirectionsIntent(SkillRequest input)
        {
            var resultEvent = SalesforceClient.Query<SF_Event_Result>(SF_Event.Query_NextEvent(SalesforceUserId));
            var nextEvent = resultEvent.records.FirstOrDefault();

            if (nextEvent == null)
            {
                return ResponseBuilder.Tell("You do not have anymore meetings for today.");
            }

            SetSessionVar(input, "Event", nextEvent.Id);


            //AwsSNS.SendMessage(System.Uri.EscapeUriString($"Directions to : http://maps.google.com/?q={nextEvent.Street_ma__c} {nextEvent.City_ma__c} {nextEvent.State_ma__c}"), "Directions");
            AwsSNS.SendMessage($"{nextEvent.Street_ma__c} {nextEvent.City_ma__c} {nextEvent.State_ma__c}", "Directions");



            return ResponseBuilder.Tell("I am sending you the routing information to your phone. Please check your text messages shortly.");
        }

        private static SkillResponse Handler_ContactInfoIntent(SkillRequest input)
        {
            var contact = PotentiallyPreviousContact(input, "ContactName");

            if (contact == null)
                return ResponseBuilder.Tell("I was unable to find that contact information.");

            var response = $"You last met with {contact.Full_Name__c} on {contact.Last_Meeting_Date__c.Value.ToShortDateString()}. ";

            if (contact.Focus_List__c)
                response += "He is a member of the Focus Group. ";

            response += $"He has ${contact.FP_Assets_Under_Management__c} in assets under management and his last ticket was for ${contact.FP_Last_Ticket_Amount__c} on {contact.FP_Last_Ticket_Date__c.Value.ToShortDateString()}. ";
            response += $"He has sold ${contact.FP_YTD_Sales_CORE__c} in the last year.";

            return ResponseBuilder.Tell(response);
        }

        private static SkillResponse Handler_ContactPersonalInfoIntent(SkillRequest input)
        {
            var contact = PotentiallyPreviousContact(input, "ContactName");

            if (contact == null)
                return ResponseBuilder.Tell("I was unable to find that contact information.");

            var response = "Here is some information I have on " + contact.Full_Name__c + ". ";

            if (ValidString(contact.Spouse_Partners_Name__c))
                response += "His spouse's name is " + contact.Spouse_Partners_Name__c + ". ";
            if (Convert.ToInt32(contact.of_Children__c.Substring(0, 1)) > 0)
                response += "He has " + Convert.ToInt32(contact.of_Children__c.Substring(0, 1)).ToString() + " kids: " + contact.Children_s_Names__c + ". ";
            if (ValidString(contact.Personal_Notes__c))
                response += contact.Personal_Notes__c + " ";
            if (ValidString(contact.Birthday_Day__c) && ValidString(contact.Birthday_Month__c))
                response += "His birthday is on " + contact.Birthday_Month__c + " " + contact.Birthday_Day__c + ". ";

            return ResponseBuilder.Tell(response);
        }

        private static SkillResponse Handler_GetOpportunityIntent(SkillRequest input)
        {
            var contactId = (string)GetSessionVar(input, "FP") ?? "0038A000007kIPPQA2";

            var opportunityResult = SalesforceClient.Query<SF_Opportunity_Result>(SF_Opportunity.Query_GetOpportunityByContactId(contactId));
            var opportunity = opportunityResult.records.FirstOrDefault(); // First

            if (opportunity == null)
            {
                return ResponseBuilder.Tell($"There are no open opportunities for {GetSessionVar(input, "FP_Name") as string}.");
            }

            SetSessionVar(input, "CurrentOpportunity", opportunity.Id);

            return ResponseBuilder.Tell($"There {(opportunityResult.records.Count > 1 ? "are" : "is")} {opportunityResult.records.Count} open {(opportunityResult.records.Count > 1 ? "opportunities" : "opportunity")} for {GetSessionVar(input, "FP_Name") as string}. The first is for {opportunity.Name} and is for the Prew Secure product for the amount of ${opportunity.Amount}.");
        }

        private static SkillResponse Handler_UpdateOpportunityIntent(SkillRequest input)
        {
            var opportunityId = (string)GetSessionVar(input, "CurrentOpportunity") ?? "0068A000004afmeQAA";

            var opportunityResult = SalesforceClient.Query<SF_Opportunity_Result>(SF_Opportunity.Query_GetOpportunityById(opportunityId));
            var opportunity = opportunityResult.records.FirstOrDefault(); // First

            if (opportunity == null)
            {
                return ResponseBuilder.Tell("Could not find Opportunity to update.");
            }

            var intentRequest = input.Request as IntentRequest;
            var dollarAmount = intentRequest.Intent.Slots["DollarAmount"].Value;

            var updateOpportunity = new SF_Opportunity_Change_Amount();

            try
            {
                updateOpportunity.Amount = Convert.ToDouble(dollarAmount);
            } catch (Exception)
            {
                updateOpportunity.Amount = 250000.0; // Demo purposes just in case.
            }

            SalesforceClient.Update(opportunity.Id, "Opportunity", updateOpportunity);

            return ResponseBuilder.Tell("Successfully updated Opportunity to $" + dollarAmount);
        }

  
        private static SkillResponse Handler_ThankYouNoteIntent(SkillRequest input)
        {
            var contactName = (string)GetSessionVar(input, "FP_Name");

            AwsSNS.SendEmail($"Dear {contactName}, Thank you for taking the time to meet with me. It was a pleasure speaking with you. I look forward to discussing the next steps.", "Meeting Followup");

            return ResponseBuilder.Tell($"I've sent a thank you note to {contactName}.");
        }

        private static SkillResponse Handler_MusicIntent(SkillRequest input)
        {
            // create the speech response
            var speech = new SsmlOutputSpeech
            {
                Ssml = "<speak>Sure. Before I go, you have the following reminder. Pick up a cake for your wife. <break time='1500ms' /> Oh, and flowers for you know who. <break time='750ms' /> wink wink.</speak>"
            };

            return ResponseBuilder.Tell(speech);
        }

        private static SkillResponse Handler_WorkWithFPIntent(SkillRequest input)
        {
            var contactId = "0038A000007kIPPQA2"; // Demo purposes in case the slots fail.
            var contactName = "Mr. John Smith"; // Demo purposes in case the slots fail.

            try
            {
                var intentRequest = input.Request as IntentRequest;
                var contactNameSlot = intentRequest.Intent.Slots["ContactName"];

                if (contactNameSlot != null)
                {
                    var names = contactNameSlot.Value.Split(" ");

                    var contactResult =
                        SalesforceClient.Query<SF_Contact_Result>(
                            SF_Contact.Query_GetContactByName(names[0], names[1]));

                    if (contactResult.records.Count > 0)
                    {
                        var contact = contactResult.records.FirstOrDefault();

                        if (contact != null)
                        {
                            contactName = contact.Full_Name__c;
                            contactId = contact.Id;
                        }
                    }
                }
            }
            catch
            {
            }


            SetSessionVar(input, "FP", contactId);
            SetSessionVar(input, "FP_Name", contactName);

            return ResponseBuilder.Tell($"You are now working with {contactName}");

        }

        private static SkillResponse Handler_GeeThanksIntent(SkillRequest input)
        {
            // create the speech response - you most likely will still have this
            const string audioUrl = "https://adamgincel.com/demo.mp3";
            const string audioToken = "123456";

            var audioResponse = ResponseBuilder.AudioPlayerPlay(PlayBehavior.ReplaceAll, audioUrl, audioToken);

            return audioResponse;
        }


        #endregion


        #region Helper Functions
        private static object GetSessionVar(SkillRequest input, string key)
        {
            var session = input.Session;

            if (session.Attributes == null || !session.Attributes.ContainsKey(key))
            {
                return null;
            }

            return session.Attributes[key];
        }

        private static void SetSessionVar(SkillRequest input, string key, object value)
        {
            var session = input.Session;

            if (session.Attributes == null)
            {
                session.Attributes = new Dictionary<string, object>();
            }

            session.Attributes[key] = value;
        }

        private static bool ValidString(string s)
        {
            return !string.IsNullOrEmpty(s);
        }

        private static readonly IDictionary<string, string> States = new Dictionary<string, string>
        {
            { "AL", "Alabama" },
            { "AK", "Alaska" },
            { "AZ", "Arizona" },
            { "AR", "Arkansas" },
            { "CA", "California" },
            { "CO", "Colorado" },
            { "CT", "Connecticut" },
            { "DE", "Delaware" },
            { "DC", "District of Columbia" },
            { "FL", "Florida" },
            { "GA", "Georgia" },
            { "HI", "Hawaii" },
            { "ID", "Idaho" },
            { "IL", "Illinois" },
            { "IN", "Indiana" },
            { "IA", "Iowa" },
            { "KS", "Kansas" },
            { "KY", "Kentucky" },
            { "LA", "Louisiana" },
            { "ME", "Maine" },
            { "MD", "Maryland" },
            { "MA", "Massachusetts" },
            { "MI", "Michigan" },
            { "MN", "Minnesota" },
            { "MS", "Mississippi" },
            { "MO", "Missouri" },
            { "MT", "Montana" },
            { "NE", "Nebraska" },
            { "NV", "Nevada" },
            { "NH", "New Hampshire" },
            { "NJ", "New Jersey" },
            { "NM", "New Mexico" },
            { "NY", "New York" },
            { "NC", "North Carolina" },
            { "ND", "North Dakota" },
            { "OH", "Ohio" },
            { "OK", "Oklahoma" },
            { "OR", "Oregon" },
            { "PA", "Pennsylvania" },
            { "RI", "Rhode Island" },
            { "SC", "South Carolina" },
            { "SD", "South Dakota" },
            { "TN", "Tennessee" },
            { "TX", "Texas" },
            { "UT", "Utah" },
            { "VT", "Vermont" },
            { "VA", "Virginia" },
            { "WA", "Washington" },
            { "WV", "West Virginia" },
            { "WI", "Wisconsin" },
            { "WY", "Wyoming" }
        };

        private static SF_Contact PotentiallyPreviousContact(SkillRequest input, string slotName)
        {
            string contactId = (string)GetSessionVar(input, "FP");
            var contactResult = SalesforceClient.Query<SF_Contact_Result>(SF_Contact.Query_GetContactById(contactId));

            //var intentRequest = input.Request as IntentRequest;
            //var contactName = intentRequest.Intent.Slots[slotName].Value;

            //string[] pronouns = { null, "", "him", "her", "them", "his", "her's", "hers", "their", "theirs" };

            //SF_Contact_Result contactResult = null;

            //if (ValidString(contactName) && pronouns.Contains(contactName.ToLower())) //"tell me more about him/her/them" means to use a session variable
            //{
            //    string contactId = (string)GetSessionVar(input, "FP");
            //    contactResult = SalesforceClient.Query<SF_Contact_Result>(SF_Contact.Query_GetContactById(contactId));
            //}
            //else
            //{
            //    var names = contactName.Split(" ");
            //    contactResult = SalesforceClient.Query<SF_Contact_Result>(SF_Contact.Query_GetContactByName(names[0], names[1]));
            //}

            return contactResult.records.FirstOrDefault();
        }
        #endregion
    }
}
