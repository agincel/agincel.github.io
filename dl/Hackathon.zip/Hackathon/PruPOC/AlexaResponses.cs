﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruPOC
{
    public static class AlexaResponses
    {
        public static string StartMessage = "You are connected to Saleslink.";
        public static string EndSession = "Your session with Saleslink has ended. Go gettem.";

        public static string HelpPrompt = "What can I help you with?";
        public static string HelpMessage = "You can say, Get My Next Meeting, or Get Account. What can I help you with?";
        public static string StopMessage = "Goodbye";
        
    }
}
