﻿using Amazon;
using Amazon.SimpleNotificationService;

namespace PruPOC
{
    public static class AwsSNS
    {
        static AwsSNS()
        {
        }

        public static void SendEmail(string message, string subject)
        {
            using (var client = new AmazonSimpleNotificationServiceClient("AKIAJRSN5HGRKX7X5CZQ", "E33hJZjDiOVKECntqwgWUdoY4AY6tSrGUSv+nZRX", RegionEndpoint.USEast1))
            {
                var publishRequest = new Amazon.SimpleNotificationService.Model.PublishRequest
                {
                    TopicArn = "arn:aws:sns:us-east-1:304088512255:Email",
                    Message = message,
                    Subject = subject
                };


                client.PublishAsync(publishRequest);
            }
        }

        public static void SendMessage(string message, string subject)
        {
            using (var client = new AmazonSimpleNotificationServiceClient("AKIAJRSN5HGRKX7X5CZQ", "E33hJZjDiOVKECntqwgWUdoY4AY6tSrGUSv+nZRX", RegionEndpoint.USEast1))
            {
                var publishRequest = new Amazon.SimpleNotificationService.Model.PublishRequest
                {
                    TopicArn = "arn:aws:sns:us-east-1:304088512255:SNS",
                    Message = message,
                    Subject = subject
                };


                client.PublishAsync(publishRequest);
            }
        }
    }
}
