﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Salesforce.Force;

namespace PruPOC.Salesforce
{
    public class SalesforceClient
    {
        private const string LoginEndpoint = "https://test.salesforce.com/services/oauth2/token";
        private const string ApiEndpoint = "/services/data/v44.0/";

        // Auth information
        private const string Username = "matthew.beutel@prudential.com.poc";
        private const string Password = "H@ckathonPOC12";
        private const string Token = "WgvO403rjfCScFG1iVDf1eNh";
        private const string ClientSecret = "96843831BD07D389C4330E07210E03870895FC62E467B849F447B6BAB82BA9C3";
        private const string ClientId = "3MVG9eQyYZ1h89HcKp6V94mJxUHAFgnrk2NZKTmb_WdnFUm7fOVcxwOPrrQKjJA74ozniri5uWv8R0hxpQPxA";

        // Returned from the authentication protocol.
        private static readonly string AuthToken;
        private static readonly string InstanceUrl;

        static SalesforceClient()
        {
            // SF requires TLS 1.1 or 1.2
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11;

            string jsonResponse;

            using (var client = new HttpClient())
            {
                var request = new FormUrlEncodedContent(new Dictionary<string, string>
                    {
                        {"grant_type", "password"},
                        {"client_id", ClientId},
                        {"client_secret", ClientSecret},
                        {"username", Username},
                        {"password", Password + Token}
                    }
                );
                request.Headers.Add("X-PrettyPrint", "1");
                var response = client.PostAsync(LoginEndpoint, request).Result;
                jsonResponse = response.Content.ReadAsStringAsync().Result;
            }

            var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(jsonResponse);

            AuthToken = values["access_token"];
            InstanceUrl = values["instance_url"];
        }

        public static void Update(string id, string objectName, object objectToUpdate)
        {
            var client = new ForceClient(InstanceUrl, AuthToken, "v44.0");

            var success = client.UpdateAsync(objectName, id, objectToUpdate).Result;

            if (!success.Success)
            {
                throw new Exception("Error performing update. Errors: " + success.Errors);
            }
        }


        public static T Query<T>(string soqlQuery)
        {
            return Send<T>(InstanceUrl + ApiEndpoint + "query", new Dictionary<string, string> {{"q", soqlQuery}} ).Result;
        }

        private static async Task<T> Send<T>(string path, Dictionary<string, string> queryParams = null)
        {
            using (var client = new HttpClient())
            {
                var request = new HttpRequestMessage(HttpMethod.Get, CreateEndpointUrl(path, queryParams));

                request.Headers.Add("Authorization", "Bearer " + AuthToken);
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                request.Headers.Add("X-PrettyPrint", "1");

                var success = false;
                var retryCount = 0;

                HttpResponseMessage response = null;

                while (!success && retryCount < 3)
                {
                    try
                    {
                        response = client.SendAsync(request).Result;

                        success = true;
                    }
                    catch
                    {
                        retryCount++;
                    }
                }

                return await HandleResponse<T>(response);
            }
        }

        /// <summary>
        /// Base handler for the responses of the web API calls.
        /// </summary>
        /// <typeparam name="T">Type of the response object.</typeparam>
        /// <param name="response">Response from the API call.</param>
        /// <returns>Awaitable response object.</returns>
        private static async Task<T> HandleResponse<T>(HttpResponseMessage response)
        {
            if (!response.IsSuccessStatusCode)
                throw new HttpRequestException(response.ToString());

            var res = await response.Content.ReadAsStringAsync();

            if (res.Equals("[]"))
                return default(T);

            try
            {
                if (typeof(T) == typeof(string))
                {
                    return (T) Convert.ChangeType(res, typeof(T));
                }

                var result = JsonConvert.DeserializeObject<T>(res);

                return result;
            }
            catch (Exception ex)
            {
                //Log.Error($"Error while parsing the response: {res}", ex);
                throw;
            }
        }


        /// <summary>
        /// Creates the full endpoint URL using the base API url and an optional collection of query parameters.
        /// </summary>
        /// <param name="path">Path to the API service to call.</param>
        /// <param name="queryParams">Collection of query parameters, or null.</param>
        /// <returns>Full URL string.</returns>
        private static string CreateEndpointUrl(string path, Dictionary<string, string> queryParams)
        {
            var sb = new StringBuilder();

            // Append the path to the service.
            sb.Append(path);

            // Append the user id.
            if (queryParams == null) queryParams = new Dictionary<string, string>();

            // Append the request parameters.
            var array = (from key in queryParams.Keys
                         select
                             $"{WebUtility.UrlEncode(key)}={WebUtility.UrlEncode(queryParams[key].ToString(CultureInfo.InvariantCulture))}")
                         .ToArray();

            if (array.Any())
                sb.Append("?").Append(string.Join("&", array));

            return sb.ToString();
        }
    }
}