﻿using System;
using System.Collections.Generic;

namespace PruPOC.Salesforce.Objects
{
    public class SF_Opportunity_Result
    {
        public int totalSize { get; set; }
        public bool done { get; set; }
        public List<SF_Opportunity> records { get; set; }
    }

    public class SF_Opportunity_Change_Amount
    {
        public double Amount { get; set; }
    }

    public class SF_Opportunity
    {
        public Attributes attributes { get; set; }
        public string AccountId { get; set; }
        public double Age__c { get; set; }
        public double Amount { get; set; }
        public string Benefit1__c { get; set; }
        public string CampaignId { get; set; }
        public double Clients_Age__c { get; set; }
        public string Client_Meeting_Date__c { get; set; }
        public string CloseDate { get; set; }
        public string Contract_Match_Date__c { get; set; }
        public string Contract_Match_Type__c { get; set; }
        public string CreatedById { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Created_By_User__c { get; set; }
        public bool Created_from_Illustration__c { get; set; }
        public string Description { get; set; }
        public string EXTERNAL_ID__c { get; set; }
        public string External_Wholesaler_User_Alignment__c { get; set; }
        public string External_Wholesaler__c { get; set; }
        public string Firm_Channel__c { get; set; }
        public string Firm_Name__c { get; set; }
        public string Fiscal { get; set; }
        public int FiscalQuarter { get; set; }
        public int FiscalYear { get; set; }
        public string ForecastCategory { get; set; }
        public string ForecastCategoryName { get; set; }
        public string FP_Name__c { get; set; }
        public bool HasOpenActivity { get; set; }
        public bool HasOpportunityLineItem { get; set; }
        public bool HasOverdueTask { get; set; }
        public string Id { get; set; }
        public string ILLUSTRATION_ID__c { get; set; }
        public bool IsClosed { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsWon { get; set; }
        public string LastActivityDate { get; set; }
        public string LastModifiedById { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string LastReferencedDate { get; set; }
        public string LastViewedDate { get; set; }
        public string LeadSource { get; set; }
        public string Matched_FPs__c { get; set; }
        public bool My_Territory__c { get; set; }
        public string Name { get; set; }
        public string NextStep { get; set; }
        public string Notes__c { get; set; }
        public string OwnerId { get; set; }
        public string Pricebook2Id { get; set; }
        public double Probability { get; set; }
        public string Product_Group__c { get; set; }
        public string Product_Name__c { get; set; }
        public string Reason_Lost__c { get; set; }
        public string RSC__c { get; set; }
        public string Source_Campaign__c { get; set; }
        public string Source_of_Funds__c { get; set; }
        public string Source_of_Opportunity__c { get; set; }
        public string SOURCE_SYSTEM__c { get; set; }
        public string StageName { get; set; }
        public string SyncedQuoteId { get; set; }
        public string Type { get; set; }


        public static string Query_GetOpportunityById(string id)
        {
            return $"SELECT {AllFields} FROM Opportunity WHERE Id = '{id}'";
        }

        public static string Query_GetOpportunityByContactId(string contactId)
        {
            return $"SELECT {AllFields} FROM Opportunity WHERE FP_Name__c = '{contactId}'";
        }

        public static string Query_All => $"SELECT {AllFields} FROM Opportunity LIMIT 10";
        public static string AllFields => @"AccountId,Age__c,Amount,Benefit1__c,CampaignId,Clients_Age__c,Client_Meeting_Date__c,CloseDate,Contract_Match_Date__c,Contract_Match_Type__c,CreatedById,CreatedDate,Created_By_User__c,Created_from_Illustration__c,Description,EXTERNAL_ID__c,External_Wholesaler_User_Alignment__c,External_Wholesaler__c,Firm_Channel__c,Firm_Name__c,Fiscal,FiscalQuarter,FiscalYear,ForecastCategory,ForecastCategoryName,FP_Name__c,HasOpenActivity,HasOpportunityLineItem,HasOverdueTask,Id,ILLUSTRATION_ID__c,IsClosed,IsDeleted,IsWon,LastActivityDate,LastModifiedById,LastModifiedDate,LastReferencedDate,LastViewedDate,LeadSource,Matched_FPs__c,My_Territory__c,Name,NextStep,Notes__c,OwnerId,Pricebook2Id,Probability,Product_Group__c,Product_Name__c,Reason_Lost__c,RSC__c,Source_Campaign__c,Source_of_Funds__c,Source_of_Opportunity__c,SOURCE_SYSTEM__c,StageName,SyncedQuoteId,Type";

    }
}
