﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruPOC.Salesforce.Objects
{
    public class Attributes
    {
        public string type { get; set; }
        public string url { get; set; }
    }

    public class Address
    {
        public object city { get; set; }
        public string country { get; set; }
        public string countryCode { get; set; }
        public object geocodeAccuracy { get; set; }
        public object latitude { get; set; }
        public object longitude { get; set; }
        public object postalCode { get; set; }
        public object state { get; set; }
        public object stateCode { get; set; }
        public object street { get; set; }
    }
}
