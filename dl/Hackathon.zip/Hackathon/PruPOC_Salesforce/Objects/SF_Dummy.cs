﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PruPOC.Salesforce.Objects
{
    public class DummyData
    {
        public static SF_Account ExampleAccount => new SF_Account
        {
            Able_to_use_our_Website__c = "Y",
            AccountNumber = "12345",
            AccountSource = "TEST",
            ADB_Status__c = "ADB Status",
            AnnualRevenue = "$100",
            Approved_Product_Group_Names__c = "N/A",
            Approved_Product_Names__c = "N/A",
            App_in_Kit__c = "?",
            Associated_Agreements__c = "None",
            AVF_Required_applicable_to_EOE_firms__c = "Y",
            BillingPostalCode = "02134",
            BillingState = "AL",
            CID__c = "98765",
            Client_Communications_Pre_approval__c = "Y",
            Commingling_of_Reps_Permitted__c = "?",
            Commission_Advance__c = "1234",
            CRD_Number__c = "5555555",
            Firm_Code__c = "8888",
            Name = "Adam Gincel",
            No_of_Meetings_MTD__c = "7",
            Notes__c = "Works at Prudential and is helping with Amazon Alexa",
            NumberOfEmployees = "3",
            Phone = "7324822618"
        };
    }
}
