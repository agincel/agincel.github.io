﻿using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using Salesforce.Force;

namespace PruPOC.Salesforce.Objects
{
    public class SF_Event_Result
    {
        public int totalSize { get; set; }
        public bool done { get; set; }
        public List<SF_Event> records { get; set; }
    }


    public class SF_EventNote
    {
        public string Notes__c { get; set; }
    }

    public class SF_Event
    {
        public Attributes attributes { get; set; }
        public string AccountId { get; set; }
        public string Action_Steps_Timeline__c { get; set; }
        public string ActivityDate { get; set; }
        public DateTime ActivityDateTime { get; set; }
        public string Agenda__c { get; set; }
        public string City_ma__c { get; set; }
        public string City__c { get; set; }
        public string Common_Meeting_ID__c { get; set; }
        public string Completed_Date__c { get; set; }
        public string Contract_Number__c { get; set; }
        public string Country_ma__c { get; set; }
        public string Country__c { get; set; }
        public string CreatedById { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Description { get; set; }
        public string Dial_in__c { get; set; }
        public string Discussion_Details__c { get; set; }
        public int DurationInMinutes { get; set; }
        public DateTime EndDateTime { get; set; }
        public string EventSubtype { get; set; }
        public string EVENT_APPOINTMENT_ID2__c { get; set; }
        public string EVENT_APPOINTMENT_ID__c { get; set; }
        public string Event_Status__c { get; set; }
        public string Event_Time_Zone__c { get; set; }
        public bool Excluded_Event__c { get; set; }
        public string Exclusion_Fields_Modified_Date__c { get; set; }
        public string EXTERNAL_ID__c { get; set; }
        public string External_Wholesaler__c { get; set; }
        public string FP_YTD_Sales__c { get; set; }
        public string GroupEventType { get; set; }
        public string Id { get; set; }
        public bool IsAllDayEvent { get; set; }
        public bool IsArchived { get; set; }
        public bool IsChild { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsGroupEvent { get; set; }
        public bool IsPrivate { get; set; }
        public bool IsRecurrence { get; set; }
        public bool IsRecurrence2 { get; set; }
        public bool IsRecurrence2Exception { get; set; }
        public bool IsRecurrence2Exclusion { get; set; }
        public bool IsReminderSet { get; set; }
        public bool Is_Activity_Completed__c { get; set; }
        public bool Is_Apex_Context__c { get; set; }
        public bool Is_Task_Created_by_Logged_in_User__c { get; set; }
        public string LastModifiedById { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string Location { get; set; }
        public string Location_Name_ma__c { get; set; }
        public string Location_Name__c { get; set; }
        public string Lotus_Notes_Subject__c { get; set; }
        public string MALatitude__c { get; set; }
        public string MALongitude__c { get; set; }
        public string Meeting_Created_By__c { get; set; }
        public string Meeting_ID_Sequence__c { get; set; }
        public string Meeting_Initiation__c { get; set; }
        public string Method_of_Communication__c { get; set; }
        public string Notes__c { get; set; }
        public string OwnerId { get; set; }
        public string Phone__c { get; set; }
        public string Primary_Phone_Extension__c { get; set; }
        public string Product_Group__c { get; set; }
        public string ProfileCheck__c { get; set; }
        public string Prudential_Attendees__c { get; set; }
        public bool Qualified_Touch__c { get; set; }
        public string RecordTypeId { get; set; }
        public string Recurrence2PatternStartDate { get; set; }
        public string Recurrence2PatternText { get; set; }
        public string Recurrence2PatternTimeZone { get; set; }
        public string Recurrence2PatternVersion { get; set; }
        public string RecurrenceActivityId { get; set; }
        public string RecurrenceDayOfMonth { get; set; }
        public string RecurrenceDayOfWeekMask { get; set; }
        public string RecurrenceEndDateOnly { get; set; }
        public string RecurrenceInstance { get; set; }
        public string RecurrenceInterval { get; set; }
        public string RecurrenceMonthOfYear { get; set; }
        public string RecurrenceStartDateTime { get; set; }
        public string RecurrenceTimeZoneSidKey { get; set; }
        public string RecurrenceType { get; set; }
        public string ReminderDateTime { get; set; }
        public bool Reminder_Task__c { get; set; }
        public string Repeat_Schedule_in_Business_Days__c { get; set; }
        public string Sales_Amount__c { get; set; }
        public bool Save_As_Individual__c { get; set; }
        public string ShowAs { get; set; }
        public string sma__BaseObjectId__c { get; set; }
        public string sma__LayerId__c { get; set; }
        public string SOURCE_SYSTEM__c { get; set; }
        public DateTime StartDateTime { get; set; }
        public string State_ma__c { get; set; }
        public string State__c { get; set; }
        public string Storm_Meeting_ID__c { get; set; }
        public string Storm_Request_ID__c { get; set; }
        public string Street_ma__c { get; set; }
        public string Street__c { get; set; }
        public string Subject { get; set; }
        public string Sub_Type__c { get; set; }
        public DateTime SystemModstamp { get; set; }
        public string TAP__c { get; set; }
        public string Touch_Value__c { get; set; }
        public string Type { get; set; }
        public string Type_of_Contact__c { get; set; }
        public string Type__c { get; set; }
        public bool Virtual_Meeting__c { get; set; }
        public int WhatCount { get; set; }
        public string WhatId { get; set; }
        public int WhoCount { get; set; }
        public string WhoId { get; set; }
        public string ZipCode_ma__c { get; set; }
        public string ZipCode__c { get; set; }

        public static string Query_NextEvent(string ownerId)
        {
            return $"SELECT {AllFields} FROM Event WHERE OwnerId = '{ownerId}' AND  ActivityDateTime >= {DateTime.UtcNow:s}Z LIMIT 1";
        }

        public static string Query_All => $"SELECT {AllFields} FROM Event";

        public static string AllFields => "AccountId,Action_Steps_Timeline__c,ActivityDate,ActivityDateTime,Agenda__c,City_ma__c,City__c,Common_Meeting_ID__c,Completed_Date__c,Contract_Number__c,Country_ma__c,Country__c,CreatedById,CreatedDate,Description,Dial_in__c,Discussion_Details__c,DurationInMinutes,EndDateTime,EventSubtype,EVENT_APPOINTMENT_ID2__c,EVENT_APPOINTMENT_ID__c,Event_Status__c,Event_Time_Zone__c,Excluded_Event__c,Exclusion_Fields_Modified_Date__c,EXTERNAL_ID__c,External_Wholesaler__c,FP_YTD_Sales__c,GroupEventType,Id,IsAllDayEvent,IsArchived,IsChild,IsDeleted,IsGroupEvent,IsPrivate,IsRecurrence,IsRecurrence2,IsRecurrence2Exception,IsRecurrence2Exclusion,IsReminderSet,Is_Activity_Completed__c,Is_Apex_Context__c,Is_Task_Created_by_Logged_in_User__c,LastModifiedById,LastModifiedDate,Location,Location_Name_ma__c,Location_Name__c,Lotus_Notes_Subject__c,MALatitude__c,MALongitude__c,Meeting_Created_By__c,Meeting_ID_Sequence__c,Meeting_Initiation__c,Method_of_Communication__c,Notes__c,OwnerId,Phone__c,Primary_Phone_Extension__c,Product_Group__c,ProfileCheck__c,Prudential_Attendees__c,Qualified_Touch__c,RecordTypeId,Recurrence2PatternStartDate,Recurrence2PatternText,Recurrence2PatternTimeZone,Recurrence2PatternVersion,RecurrenceActivityId,RecurrenceDayOfMonth,RecurrenceDayOfWeekMask,RecurrenceEndDateOnly,RecurrenceInstance,RecurrenceInterval,RecurrenceMonthOfYear,RecurrenceStartDateTime,RecurrenceTimeZoneSidKey,RecurrenceType,ReminderDateTime,Reminder_Task__c,Repeat_Schedule_in_Business_Days__c,Sales_Amount__c,Save_As_Individual__c,ShowAs,sma__BaseObjectId__c,sma__LayerId__c,SOURCE_SYSTEM__c,StartDateTime,State_ma__c,State__c,Storm_Meeting_ID__c,Storm_Request_ID__c,Street_ma__c,Street__c,Subject,Sub_Type__c,SystemModstamp,TAP__c,Touch_Value__c,Type,Type_of_Contact__c,Type__c,Virtual_Meeting__c,WhatCount,WhatId,WhoCount,WhoId,ZipCode_ma__c,ZipCode__c";

    }
}
