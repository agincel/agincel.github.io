﻿using System;
using System.IO;
using System.Linq;
using PruPOC.Salesforce;
using PruPOC.Salesforce.Objects;

namespace POCTestConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            //PruPOC.AwsSNS.SendMessage("Test from Jatin", "Directions");
            //File.WriteAllText(@"E:\Out-Accounts.txt", SalesforceClient.Query<string>(SF_Account.AllResultsQuery));
            //File.WriteAllText(@"E:\Out-Contacts.txt", SalesforceClient.Query<string>(SF_Contact.AllResultsQuery));
            //File.WriteAllText(@"E:\Out-Events.txt", SalesforceClient.Query<string>(SF_Event.AllResultsQuery));
            //File.WriteAllText(@"C:\Development\Out-Opportunity.txt", SalesforceClient.Query<string>(SF_Opportunity.Query_All));

            //Console.WriteLine(SalesforceClient.Describe("Account"));
            //Console.WriteLine(SalesforceClient.Describe("Contact"));
            //Console.WriteLine(SalesforceClient.QueryEndpoints());

            var resultEvent = SalesforceClient.Query<SF_Event_Result>(SF_Event.Query_NextEvent("0051a000002zf6aAAA"));
            var nextEvent = resultEvent.records.FirstOrDefault();

            var opportunityResult = SalesforceClient.Query<SF_Opportunity_Result>(SF_Opportunity.Query_GetOpportunityByContactId("0038A000007kIPPQA2"));
            var opportunity = opportunityResult.records.FirstOrDefault(); // First

            //var result = SalesforceClient.Query<SF_Account_Result>(SF_Account.AllResultsQuery);
            //Console.WriteLine(result.records.FirstOrDefault().Name);

            //var result2 = SalesforceClient.Query<SF_Contact_Result>(SF_Contact.AllResultsQuery);
            //Console.WriteLine(result2.records.FirstOrDefault().Name);


            Console.ReadLine();
        }
    }
}
